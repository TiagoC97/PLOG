/**
* Animation
* @constructor
* @abstract
*/
function Animation(scene) {
  if (this.constructor === Animation) {
    throw new Error('Cannot instanciate abstract class');
  }
  this.scene = scene;
};

Animation.prototype.constructor = Animation;

Animation.prototype.update = function(curTime, curNode) {
  throw new Error("Abstract method!");
}


Animation.prototype.applyMatrix = function() {
  throw new Error("Abstract method!");
}
