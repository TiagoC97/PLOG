/**
* ComboAnimation
* @constructor
*/
function ComboAnimation(scene, anis) {
  Animation.call(this, scene);

  this.anis = anis;

  this.anisLength = anis.length;
  this.curCombo = 0;
};


ComboAnimation.prototype.update = function(curTime, curNode) {

  let startTime = curNode.startTime;
  this.curCombo = curNode.curCombo;

  let deltaT = (curTime - startTime) / 1000;

  let state = this.anis[this.curCombo].update(curTime, curNode);
  if (state == DONE){
    if (this.curCombo < this.anis.length - 1){
      curNode.nextCombo(Date.now());
    } else {
      return DONE;
    }
  }
  return CONTINUE;
}

ComboAnimation.prototype.applyMatrix = function() {
  this.anis[this.curCombo].applyMatrix();
}
