/**
* MyCylinder
* @constructor
*/
function MyCylinder(scene, args) {
  CGFobject.call(this, scene);

  this.args = args;

  this.initBuffers();
};

MyCylinder.prototype = Object.create(CGFobject.prototype);
MyCylinder.prototype.constructor = MyCylinder;

MyCylinder.prototype.initBuffers = function() {

  this.vertices = [];

  this.indices = [];

  this.normals = [];

  this.texCoords = [];

  //Valores recebidos
  this.height = this.args[0];
  this.botRad = this.args[1];
  this.topRad = this.args[2];
  this.stacks = this.args[3];
  this.slices = this.args[4];
  this.topcap = this.args[5];
  this.botcap = this.args[6];


  this.ang = 2 * Math.PI / (this.slices);


  //Calculo da componente z da normal a superficie
  if(this.botRad != this.topRad){
    var alfa = Math.atan( this.height / (this.botRad-this.topRad) );
    var theta = Math.PI/2 - alfa;
    var znormal = Math.tan(theta) * Math.abs(this.botRad-this.topRad);
  }
  else var znormal = 0;


  //Superficie lateral
  for (var stack = 0; stack <= this.stacks; stack++) {
    for (var slice = 0; slice <= this.slices; slice++) {
      this.curRad = (this.botRad * (this.stacks - stack) + this.topRad * stack) / this.stacks;
      this.vertices.push(Math.cos(slice * this.ang) * this.curRad, Math.sin(slice * this.ang) * this.curRad, (stack / this.stacks) * this.height);
      this.normals.push((Math.cos(slice * this.ang)), (Math.sin(slice * this.ang)), znormal);
    }
  }

  for (var stack = 0; stack < this.stacks; stack++) {
    for (var slice = 0; slice < this.slices; slice++) {
      this.indices.push(stack * (this.slices + 1) + slice, stack * (this.slices + 1) + slice + 1, (stack + 1) * (this.slices + 1) + slice);
      this.indices.push(stack * (this.slices + 1) + slice + 1, (stack + 1) * (this.slices + 1) + slice + 1, (stack + 1) * (this.slices + 1) + slice);
    }
  }

  //Tampas
  if ( this.topcap == 1 ) {
    for (var slice = 0; slice <= this.slices; slice++) {
      this.vertices.push(Math.cos(slice * this.ang) * this.topRad, Math.sin(slice * this.ang) * this.topRad, this.height);
      this.normals.push(0, 0, 1);
    }
    this.vertices.push(0, 0, this.height);
    this.normals.push(0, 0, 1);
    for (var slice = 0; slice < this.slices; slice++) {
      this.indices.push((this.stacks + 1 ) * (this.slices + 1) + slice, (this.stacks + 1 ) * (this.slices + 1) + slice + 1, (this.stacks + 2) * (this.slices + 1));
    }
  }

  if ( this.botcap == 1 ) {
    for (var slice = 0; slice <= this.slices; slice++) {
      this.vertices.push(Math.cos(slice * this.ang) * this.botRad, Math.sin(slice * this.ang) * this.botRad, 0);
      this.normals.push(0, 0, -1);
    }
    this.vertices.push(0, 0, 0);
    this.normals.push(0, 0, -1);
    for (var slice = 0; slice < this.slices; slice++) {
      this.indices.push((this.stacks + 1 + this.topcap) * (this.slices + 1) + slice + this.topcap, (this.stacks + 2 + this.topcap) * (this.slices + 1) + this.topcap, (this.stacks + 1 + this.topcap) * (this.slices + 1) + slice + this.topcap + 1);
    }
  }

  //Tex Coords Superficie lateral
  var sLength = 1 / this.slices;
  var tLength = 1 / this.stacks;

  for (var t = 0; t <= this.stacks; t++) {
    for (var s = 0; s <= this.slices; s++) {
      this.curRad = (this.botRad * (this.stacks - t) + this.topRad * t) / this.stacks;
      this.peri = 2 * Math.PI * this.curRad;
      this.texCoords.push(sLength * s, 1 - tLength * t);
    }
  }

  //Tex Coords Tampas
  if ( this.topcap == 1){
    for (var slice = 0; slice <= this.slices; slice++)
    {
      this.texCoords.push((1 + Math.cos(slice * this.ang))/2, (1 - Math.sin(slice * this.ang))/2);
    }
    this.texCoords.push(0.5, 0.5);
  }

  if ( this.botcap == 1){
    for (var slice = 0; slice <= this.slices; slice++)
    {
      this.texCoords.push((1 + Math.cos(slice * this.ang))/2, (1 - Math.sin(slice * this.ang))/2);
    }
    this.texCoords.push(0.5, 0.5);
  }

  this.primitiveType = this.scene.gl.TRIANGLES;
  this.initGLBuffers();
}
;

MyCylinder.prototype.setAmplifFactor = function(amplif_s, amplif_t) {

  //Esta correto mas nao foi necessario

  /*
  var sLength = 1 / this.slices;
  var tLength = 1 / this.stacks;

  for (var t = 0; t <= this.stacks; t++) {
  for (var s = 0; s <= this.slices; s++) {
  this.curRad = (this.botRad * (this.stacks - t) + this.topRad * t) / this.stacks;
  this.peri = 2 * Math.PI * this.curRad;
  this.texCoords.push(sLength * s * this.peri / amplif_s, tLength * t * this.height / amplif_t);
}
}

if ( this.topcap == 1){
for (var slice = 0; slice <= this.slices; slice++)
{
this.texCoords.push((1 + Math.cos(slice * this.ang))/2, (1 - Math.sin(slice * this.ang))/2);
}
this.texCoords.push(0.5, 0.5);
}

if ( this.botcap == 1){
for (var slice = 0; slice <= this.slices; slice++)
{
this.texCoords.push((1 + Math.cos(slice * this.ang))/2, (1 - Math.sin(slice * this.ang))/2);
}
this.texCoords.push(0.5, 0.5);
}

this.updateTexCoordsGLBuffers();
*/

}
