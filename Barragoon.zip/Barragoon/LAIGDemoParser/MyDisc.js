/**
 * MyDisc
 * @constructor
 */
 function MyDisc(scene, args) {
 	CGFobject.call(this,scene);

	this.slices = args;

 	this.initBuffers();
 };

 MyDisc.prototype = Object.create(CGFobject.prototype);
 MyDisc.prototype.constructor = MyDisc;

 MyDisc.prototype.initBuffers = function() {

 	this.indices = [];
 	this.vertices = [];
 	this.normals = [];
 	this.texCoords = [];

	var ang = 2 * Math.PI / (this.slices);

	//Tampas

	for (var slice = 0; slice < this.slices; slice++)
		{
		this.vertices.push(Math.cos(slice * ang), Math.sin(slice * ang), 0);
		this.normals.push(0, 0, 1);
		this.texCoords.push((1 + Math.cos(slice * ang))/2, (1 - Math.sin(slice * ang))/2);
		}

	this.vertices.push(0, 0, 0);
	this.normals.push(0, 0, 1);
	this.texCoords.push(0.5, 0.5);

	for (var slice = 0; slice < this.slices; slice++)
		{
			if (slice == this.slices - 1){
				this.indices.push(slice, 0, this.slices);
			}

			else{
				this.indices.push(slice, slice + 1, this.slices);
				}
		}

 	this.primitiveType = this.scene.gl.TRIANGLES;
	this.initGLBuffers();
 };

 MyCylinder.prototype.setAmplifFactor = function(amplif_s, amplif_t) {

 }
