/**
* MyTriangle
* @constructor
*/
function MyTriangle(scene, args) {
  CGFobject.call(this,scene);

  this.args = args;

  this.initBuffers();
};

MyTriangle.prototype = Object.create(CGFobject.prototype);
MyTriangle.prototype.constructor = MyTriangle;

MyTriangle.prototype.initBuffers = function() {
  this.vertices = [];

  for (let i = 0; i < this.args.length; i++){
    this.vertices.push(this.args[i]);
  }

  this.indices = [
    0, 1, 2
  ];

  this.normals = [];

  //Calculo das componentes x, y e z das normais dependendo das coordenadas dos vertices
  this.nx = (this.args[4]-this.args[1])*(this.args[8]-this.args[2]) - (this.args[5]-this.args[2])*(this.args[7]-this.args[1]);
  this.ny = (this.args[5]-this.args[2])*(this.args[6]-this.args[0]) - (this.args[3]-this.args[0])*(this.args[8]-this.args[2]);
  this.nz = (this.args[3]-this.args[0])*(this.args[7]-this.args[1]) - (this.args[4]-this.args[1])*(this.args[6]-this.args[0]);

  for (let j = 0; j < 3; j++){
    this.normals.push(this.nx);
    this.normals.push(this.ny);
    this.normals.push(this.nz);
  }

  this.texCoords = [];

  var ab = [
    this.args[3]-this.args[0],
    this.args[4]-this.args[1],
    this.args[5]-this.args[2]
  ];

  var ac = [
    this.args[6]-this.args[0],
    this.args[7]-this.args[1],
    this.args[8]-this.args[2]
  ];

  this.abcomp = Math.sqrt(Math.pow(this.args[0] - this.args[3], 2) + Math.pow(this.args[1] - this.args[4], 2) + Math.pow(this.args[2] - this.args[5], 2));
  var accomp = Math.sqrt(Math.pow(this.args[0] - this.args[6], 2) + Math.pow(this.args[1] - this.args[7], 2) + Math.pow(this.args[2] - this.args[8], 2));

  var costheta = (ab[0] * ac[0] + ab[1] * ac[1] + ab[2] * ac[2]) / (this.abcomp * accomp);
  this.cs = costheta * accomp;
  this.ct = Math.sqrt(Math.pow(accomp, 2) - Math.pow(this.cs, 2));


  this.primitiveType = this.scene.gl.TRIANGLES;
  this.initGLBuffers();
};


MyTriangle.prototype.setAmplifFactor = function(amplif_s, amplif_t) {
  if (this.abcomp/amplif_s != this.texCoords[2] || 1 - 1-this.ct/amplif_t != this.texCoords[5]) {

  this.texCoords = [
    0, 1,
    this.abcomp/amplif_s, 1,
    this.cs/amplif_s, 1-this.ct/amplif_t
  ];

  this.updateTexCoordsGLBuffers();
  }

}
