LAIG Demo Parser

Base code and demo scene provided by:
- Rui Pedro Peixoto Cardoso - up201305469@fe.up.pt
- Diogo da Silva Amaral - up201306082@fe.up.pt

Adapted by:
- Rui Rodrigues - rui.rodrigues@fe.up.pt