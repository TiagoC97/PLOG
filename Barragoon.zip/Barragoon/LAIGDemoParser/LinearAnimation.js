/**
* LinearAnimation
* @constructor
*/
function LinearAnimation(scene, speed, controlPoints) {
  Animation.call(this, scene);

  this.speed = speed;

  this.xCoord = controlPoints[0][0];
  this.yCoord = controlPoints[0][1];
  this.zCoord = controlPoints[0][2];

  this.maxLine = controlPoints.length - 2;

  this.lines = [];

  let startX;
  let startY;
  let startZ;
  let goalX;
  let goalY;
  let goalZ;
  let deltaX;
  let deltaY;
  let deltaZ;
  let angHor;
  let angVer;

  for (let i = 1; i < controlPoints.length; i++) {
    startX = controlPoints[i-1][0];
    startY = controlPoints[i-1][1];
    startZ = controlPoints[i-1][2];

    goalX = controlPoints[i][0];
    goalY = controlPoints[i][1];
    goalZ = controlPoints[i][2];

    deltaX = goalX - startX;
    deltaY = goalY - startY;
    deltaZ = goalZ - startZ;

    if (deltaZ == 0)
    angHor = Math.sign(deltaX) * Math.PI / 2;
    else {
      angHor = Math.atan(deltaX / deltaZ);
      if (deltaZ < 0)
      angHor += Math.PI;
    }
    if (deltaX == 0 && deltaZ == 0)
    angVer = Math.sign(deltaY) * Math.PI / 2;
    else angVer = Math.atan(deltaY / Math.sqrt(Math.pow(deltaX, 2) + Math.pow(deltaZ, 2)));

    let line = [
      startX, startY, startZ,
      goalX, goalY, goalZ,
      deltaX, deltaY, deltaZ,
      angVer, angHor
    ];
    this.lines.push(line);
  }

  this.angHor = angHor;
};


LinearAnimation.prototype.update = function(curTime, curNode) {

  let startTime = curNode.startTime;
  let curLinear = curNode.curLinear;

  let deltaT = (curTime - startTime) / 1000;
  let startX = this.lines[curLinear][0];
  let startY = this.lines[curLinear][1];
  let startZ = this.lines[curLinear][2];
  let goalX = this.lines[curLinear][3];
  let goalY = this.lines[curLinear][4];
  let goalZ = this.lines[curLinear][5];
  let deltaX = this.lines[curLinear][6];
  let deltaY = this.lines[curLinear][7];
  let deltaZ = this.lines[curLinear][8];
  let angVer = this.lines[curLinear][9];
  let dirX = Math.sign(deltaX);
  let dirY = Math.sign(deltaY);
  let dirZ = Math.sign(deltaZ);
  this.angHor = this.lines[curLinear][10];

  this.xCoord = startX + this.speed * deltaT * Math.sin(this.angHor) * Math.cos(angVer);
  this.yCoord = startY + this.speed * deltaT * Math.sin(angVer);
  this.zCoord = startZ + this.speed * deltaT * Math.cos(this.angHor) * Math.cos(angVer);

  if (this.xCoord * dirX >= goalX * dirX &&
    this.yCoord * dirY >= goalY * dirY &&
    this.zCoord * dirZ >= goalZ * dirZ) {

      this.xCoord = goalX;
      this.yCoord = goalY;
      this.zCoord = goalZ;

      if (curLinear < this.maxLine) {
        curNode.nextLinear(Date.now());
      }
      else return DONE;
    }
    return CONTINUE;
  }


  LinearAnimation.prototype.applyMatrix = function() {
    this.scene.translate(this.xCoord, this.yCoord, this.zCoord);
    this.scene.rotate(this.angHor, 0, 1, 0);
  }
