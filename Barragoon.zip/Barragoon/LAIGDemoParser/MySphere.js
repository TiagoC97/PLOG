/**
* MySphere
* @constructor
*/
function MySphere(scene, args) {
  CGFobject.call(this,scene);

  this.args = args;

  this.initBuffers();
};

MySphere.prototype = Object.create(CGFobject.prototype);
MySphere.prototype.constructor = MySphere;

MySphere.prototype.initBuffers = function() {
  this.vertices = [];

  this.indices = [];

  this.normals = [];

  this.texCoords = [];

  //Valores recebidos
  this.rad = this.args[0];
  this.stacks = this.args[1];
  this.slices = this.args[2];

  var ang = 2 * Math.PI / this.slices;
  var angHeight = Math.PI / (this.stacks + 1);

  //Superficie curva
  for (var stack = 1; stack <= this.stacks; stack++)
  {
    for (var slice = 0; slice <= this.slices; slice++)
    {
      this.vertices.push(Math.cos(slice * ang) * Math.cos(- Math.PI/2 + stack * angHeight) * this.rad, Math.sin(slice * ang) * Math.cos(- Math.PI/2 + stack * angHeight) * this.rad, Math.sin(- Math.PI/2 + stack * angHeight) * this.rad);
      this.normals.push(Math.cos(slice * ang) * Math.cos(- Math.PI/2 + stack * angHeight), Math.sin(slice * ang) * Math.cos(- Math.PI/2 + stack * angHeight), Math.sin(- Math.PI/2 + stack * angHeight));
    }
  }

  //Vertices dos polos
  this.vertices.push(0, 0, this.rad);
  this.normals.push(0, 0, 1);

  this.vertices.push(0, 0, -this.rad);
  this.normals.push(0, 0, -1);


  for (var stack = 0; stack < this.stacks; stack++)
  {
    for (var slice = 0; slice < this.slices; slice++)
    {
      if(stack == this.stacks - 1){
        this.indices.push((stack * (this.slices + 1) + slice), (stack * (this.slices + 1) + slice) + 1, (this.slices + 1) * this.stacks);
        this.indices.push(slice, (this.slices + 1) * this.stacks + 1, slice + 1);
      }
      else{
        this.indices.push((stack * (this.slices + 1) + slice), (stack * (this.slices + 1) + slice) + 1, ((stack + 1) * (this.slices + 1) + slice));
        this.indices.push((stack * (this.slices + 1) + slice) + 1, ((stack + 1) * (this.slices + 1) + slice) + 1, ((stack + 1) * (this.slices + 1) + slice));

      }
    }
  }

  //Tex Coords Superficie curva
  var sLength = 1/this.slices;
  var tLength = 1/(this.stacks + 1);

  for(var t = 1; t <= this.stacks; t++){
    for(var s = 0; s <= this.slices; s++){
      this.texCoords.push(sLength * s, 1 - tLength * t);
    }
  }

  //Tex Coords Vertices dos polos
  this.texCoords.push(0.5, 0);
  this.texCoords.push(0.5, 1);


  this.primitiveType = this.scene.gl.TRIANGLES;
  this.initGLBuffers();
};


MySphere.prototype.setAmplifFactor = function(amplif_s, amplif_t) {

  //certo??
  /*
  var sLength = 1/this.slices;
  var tLength = 1/this.stacks;
  var sheight = 2*this.rad/(this.stacks+1);
  var meioperi = this.rad*Math.PI;

  for(var t = 0; t < this.stacks; t++){
  for(var s = 0; s <= this.slices; s++){
  this.curRad = Math.sqrt(Math.pow(this.rad, 2) - Math.pow(Math.abs(this.rad-sheight), 2));
  this.periPar = 2 * Math.PI * this.curRad;
  this.texCoords.push(1-sLength * s * this.periPar / amplif_s, 1-tLength * t * meioperi / amplif_t);
}
}

this.texCoords.push(0.5, 0);
this.texCoords.push(0.5, 1);



var sLength = 1/this.slices;
var tLength = 1/this.stacks;

for(var t = 0; t < this.stacks; t++){
for(var s = 0; s <= this.slices; s++){
this.texCoords.push(sLength * s, 1-tLength * t);
}
}

this.texCoords.push(0.5, 0);
this.texCoords.push(0.5, 1);

this.updateTexCoordsGLBuffers();
*/
}
