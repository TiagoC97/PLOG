/**
* MyGraphLeaf class, representing a leaf in the scene graph.
* @constructor
**/

function MyGraphLeaf(graph, xmlelem) {
  this.graph = graph;

  this.xmlelem = xmlelem;

  this.primitive = null;

  this.type = this.graph.reader.getItem(this.xmlelem, 'type', ['rectangle', 'cylinder', 'sphere', 'triangle', 'patch', 'disc']);

  //Argumentos passados as primitivas
  var args = this.graph.reader.getString(this.xmlelem, 'args').split(" ");
  //variavel usada caso haja erros e seja preciso sair do switch
  var exit = false;

  /*
  * Em cada case é verificado se os argumentos lidos do xml sao validos conforme as especificaçoes dadas
  * No caso de excesso de "espaços" antes, depois ou entre os args no xml é dado o erro de "invalid number of args"
  */
  switch (this.type) {

    //RETANGULO
    case "rectangle":
    if ( args.length != 4 ) {
      this.graph.onXMLMinorError(this.type +": Number of args should be 4");
      break; }
      for(let i = 0; i < args.length; i++) {
        if (!isNaN(args[i]))
        args[i] = parseFloat(args[i]);
        else {
          this.graph.onXMLMinorError(this.type +": args[" + i + "] should be a number");
          exit = true;
          break;
        }
      }
      if (exit) break;
      if ((args[0] >= args[2]) || (args[1] <= args[3])){
        this.graph.onXMLMinorError(this.type +": args should be 2D coordinates for left-top and right-bottom vertices");
        break;
      }
      this.primitive = new MyRectangle(this.graph.scene, args);
      break;

      //TRIANGULO
      case "triangle":
      if ( args.length != 9 ) {
        this.graph.onXMLMinorError(this.type +": Number of args should be 9");
        break;
      }
      for(let i = 0; i < args.length; i++) {
        if (!isNaN(args[i]))
        args[i] = parseFloat(args[i]);
        else {
          this.graph.onXMLMinorError(this.type +": args[" + i + "] should be a number");
          exit = true;
          break;
        }
      }
      if (exit) break;
      this.primitive = new MyTriangle(this.graph.scene, args);
      break;

      //CILINDRO
      case "cylinder":
      if ( args.length != 7 ) {
        this.graph.onXMLMinorError(this.type +": Number of args should be 7");
        break;
      }
      for(let i = 0; i < 3; i++) {
        if (!isNaN(args[i]))
        args[i] = parseFloat(args[i]);
        else {
          this.graph.onXMLMinorError(this.type +": args[" + i + "] should be a number");
          exit = true;
          break;
        }
      }
      if (exit) break;
      for(let i = 3; i < 7; i++) {
        if (!isNaN(args[i]))
        args[i] = parseInt(args[i]);
        else {
          this.graph.onXMLMinorError(this.type +": args[" + i + "] should be a number");
          exit = true;
          break;
        }
      }
      if (exit) break;
      if ((args[5] != 0 && args[5] != 1) || (args[6] != 0 && args[6] != 1)) {
        this.graph.onXMLMinorError(this.type +": args[5] and args[6] should be 0 or 1");
        break;
      }
      this.primitive = new MyCylinder(this.graph.scene, args);
      break;

      //ESFERA
      case "sphere":
      if ( args.length != 3 ) {
        this.graph.onXMLMinorError(this.type +": Number of args should be 3");
        break;
      }
      for(let i = 0; i < 3; i++){
        if (isNaN(args[i])){
          this.graph.onXMLMinorError(this.type +": args[" + i + "] should be a number");
          exit = true;
          break;
        }
      }
      if (exit) break;
      args[0] = parseFloat(args[0]);
      args[1] = parseInt(args[1]);
      args[2] = parseInt(args[2]);
      this.primitive = new MySphere(this.graph.scene, args);
      break;

      //NURBS
      case "patch":
      if ( args.length != 2 ) {
        this.graph.onXMLMinorError(this.type +": Number of args should be 2");
        break;
      }
      for(let i = 0; i < args.length; i++) {
        if (!isNaN(args[i]))
        args[i] = parseFloat(args[i]);
        else {
          this.graph.onXMLMinorError(this.type +": args[" + i + "] should be a number");
          exit = true;
          break;
        }
      }
      if (exit) break;
      var ctrlvertexes = this.patchPoints(this.xmlelem);
      this.primitive = new MyPatch(this.graph.scene, args, ctrlvertexes);
      break;

      //Disc
      case "disc":
      if ( args.length != 1 ) {
        this.graph.onXMLMinorError(this.type +": Number of args should be 1");
        break; }
        for(let i = 0; i < args.length; i++) {
          if (!isNaN(args[i]))
          args[i] = parseInt(args[i]);
          else {
            this.graph.onXMLMinorError(this.type +": args[" + i + "] should be an integer");
            exit = true;
            break;
          }
        }
        if (exit) break;
        this.primitive = new MyDisc(this.graph.scene, args);
      break;

      default:
      break;

    }

    // The material ID.
    this.materialID = null ;

    // The texture ID.
    this.textureID = null ;

    this.transformMatrix = mat4.create();
    mat4.identity(this.transformMatrix);
  }

  MyGraphLeaf.prototype.display = function(texture) {

    if (texture != null) { //Se for null entao a textura e clear
      this.primitive.setAmplifFactor(texture[1], texture[2]);
      texture[0].bind();
    }
    this.primitive.display();

  }

  MyGraphLeaf.prototype.patchPoints = function(patch) {

    //Funçao usada para criar matriz de cplines e cpoints

    var matrix = [];

    for (let i = 0; i < patch.children.length; i++) {
      var line = [];
      for (let j = 0; j < patch.children[i].children.length; j++) {
        var point = [];
        point.push(parseFloat(this.graph.reader.getString(patch.children[i].children[j], 'xx')));
        point.push(parseFloat(this.graph.reader.getString(patch.children[i].children[j], 'yy')));
        point.push(parseFloat(this.graph.reader.getString(patch.children[i].children[j], 'zz')));
        point.push(parseFloat(this.graph.reader.getString(patch.children[i].children[j], 'ww')));
        line.push(point);
      }
      matrix.push(line);
    }

    return matrix;
  }
