/**
* BezierAnimation
* @constructor
*/
function BezierAnimation(scene, speed, controlPoints) {
  Animation.call(this, scene);

  this.speed = speed;

  this.P1 = [];
  this.P2 = [];
  this.P3 = [];
  this.P4 = [];

  for(let i = 0; i < 3; i++) {
    this.P1.push(controlPoints[0][i]);
    this.P2.push(controlPoints[1][i]);
    this.P3.push(controlPoints[2][i]);
    this.P4.push(controlPoints[3][i]);
  }

  this.t = 0;

  this.xDer = 0;
  this.zDer = 0;

  this.xCoord = this.P1[0];
  this.yCoord = this.P1[1];
  this.zCoord = this.P1[2];
  this.ang = 0;

  let Deg = 1;

  this.length = this.casteljau(this.P1, this.P2, this.P3, this.P4, Deg);
};


BezierAnimation.prototype.update = function(curTime, curNode) {

  let startTime = curNode.startTime;

  let deltaT = (curTime - startTime) / 1000;

  let deltaDist = this.speed * deltaT;

  this.t = deltaDist / this.length;

  if (this.t < 1) {
    this.setParameters(this.P1, this.P2, this.P3, this.P4);
    return CONTINUE;
  } else {
    this.t = 1;
    this.setParameters(this.P1, this.P2, this.P3, this.P4);
    return DONE;
  }
}

BezierAnimation.prototype.bezier = function(P1, P2, P3, P4) {
  return (
    Math.pow(1 - this.t, 3) * P1
    + 3 * this.t * Math.pow(1 - this.t, 2) * P2
    + 3 * Math.pow(this.t, 2) * (1 - this.t) * P3
    + Math.pow(this.t, 3) * P4
  );
}

BezierAnimation.prototype.bezierDerivate = function(P1, P2, P3, P4) {
  return (
    3 * Math.pow(1 - this.t, 2) * (P2 - P1)
    + 6 * (1 - this.t) * this.t * (P3 - P2)
    + 3 * Math.pow(this.t, 2) * (P4 - P3)
  );
}

BezierAnimation.prototype.setParameters = function(P1, P2, P3, P4) {
  this.xCoord = this.bezier(P1[0], P2[0], P3[0], P4[0]);
  this.yCoord = this.bezier(P1[1], P2[1], P3[1], P4[1]);
  this.zCoord = this.bezier(P1[2], P2[2], P3[2], P4[2]);

  this.xDer = this.bezierDerivate(P1[0], P2[0], P3[0], P4[0]);
  this.zDer = this.bezierDerivate(P1[2], P2[2], P3[2], P4[2]);

  if (this.zDer < 0) this.ang = Math.atan( this.xDer / this.zDer ) + Math.PI;
  else this.ang = Math.atan( this.xDer / this.zDer );
}

BezierAnimation.prototype.applyMatrix = function() {
  this.scene.translate(this.xCoord, this.yCoord, this.zCoord);
  this.scene.rotate(this.ang, 0, 1, 0);
}

BezierAnimation.prototype.casteljau = function(P1, P2, P3, P4, Deg) {
  let L1 = P1;
  let L2 = [];
  let H = [];
  let L3 = [];
  let R3 = [];
  let R2 = [];
  let L4 = [];
  let R4 = P4;
  let length = 0;

  L2.push((P1[0]+P2[0])/2);
  L2.push((P1[1]+P2[1])/2);
  L2.push((P1[2]+P2[2])/2);

  H.push((P2[0]+P3[0])/2);
  H.push((P2[1]+P3[1])/2);
  H.push((P2[2]+P3[2])/2);

  L3.push((L2[0]+H[0])/2);
  L3.push((L2[1]+H[1])/2);
  L3.push((L2[2]+H[2])/2);

  R3.push((P3[0]+P4[0])/2);
  R3.push((P3[1]+P4[1])/2);
  R3.push((P3[2]+P4[2])/2);

  R2.push((H[0]+R3[0])/2);
  R2.push((H[1]+R3[1])/2);
  R2.push((H[2]+R3[2])/2);

  L4.push((L3[0]+R2[0])/2);
  L4.push((L3[1]+R2[1])/2);
  L4.push((L3[2]+R2[2])/2);

  let R1 = L4;

  if (Deg == 1) {
    length += Math.sqrt( Math.pow(L2[0] - L1[0], 2) + Math.pow(L2[1] - L1[1], 2) + Math.pow(L2[2] - L1[2], 2) );
    length += Math.sqrt( Math.pow(L3[0] - L2[0], 2) + Math.pow(L3[1] - L2[1], 2) + Math.pow(L3[2] - L2[2], 2) );
    length += Math.sqrt( Math.pow(L4[0] - L3[0], 2) + Math.pow(L4[1] - L3[1], 2) + Math.pow(L4[2] - L3[2], 2) );
    length += Math.sqrt( Math.pow(R2[0] - R1[0], 2) + Math.pow(R2[1] - R1[1], 2) + Math.pow(R2[2] - R1[2], 2) );
    length += Math.sqrt( Math.pow(R3[0] - R2[0], 2) + Math.pow(R3[1] - R2[1], 2) + Math.pow(R3[2] - R2[2], 2) );
    length += Math.sqrt( Math.pow(R4[0] - R3[0], 2) + Math.pow(R4[1] - R3[1], 2) + Math.pow(R4[2] - R3[2], 2) );
  }
  else {
    length += this.casteljau(L1, L2, L3, L4, Deg-1);
    length += this.casteljau(R1, R2, R3, R4, Deg-1);
  }
  return length;
}
