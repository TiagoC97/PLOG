/**
* MyRectangle
* @constructor
*/
function InvisibleSquare(scene, x, z, id) {
  CGFobject.call(this,scene);

  this.scene = scene;

  let args = [0, 1, 1, 0];
  this.square = new MyRectangle(scene, args);
  this.x = x;
  this.z = z;
  this.id = id;

};

InvisibleSquare.prototype = Object.create(CGFobject.prototype);
InvisibleSquare.prototype.constructor = InvisibleSquare;

InvisibleSquare.prototype.display = function(){
  this.scene.pushMatrix();
    this.scene.translate(this.x, 0, this.z);
    this.square.display();
  this.scene.popMatrix();
}
