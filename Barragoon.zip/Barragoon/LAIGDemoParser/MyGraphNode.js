/**
* MyGraphNode class, representing an intermediate node in the scene graph.
* @constructor
**/

function MyGraphNode(graph, nodeID) {
  this.graph = graph;

  this.nodeID = nodeID;

  // IDs of child nodes.
  this.children = [];

  // IDs of leaves nodes.
  this.leaves = [];

  // The material ID.
  this.materialID = null;

  // The texture ID.
  this.textureID = null;

  // The animation ids
  this.animationIDs = null;

  // The iterators
  this.curAni = 0;
  this.curCombo = 0;
  this.curLinear = 0;

  // Start time of current animation
  this.startTime;

  this.transformMatrix = mat4.create();
  mat4.identity(this.transformMatrix);
}

/**
* Adds the reference (ID) of another node to this node's children array.
*/
MyGraphNode.prototype.addChild = function(nodeID) {
  this.children.push(nodeID);
}

/**
* Adds a leaf to this node's leaves array.
*/
MyGraphNode.prototype.addLeaf = function(leaf) {
  this.leaves.push(leaf);
}

MyGraphNode.prototype.setStartTime = function(startTime) {
  this.startTime = startTime;
}

MyGraphNode.prototype.nextAni = function(startTime) {
  if (this.curAni < this.animationIDs.length - 1){
    this.curAni++;
    this.curCombo = 0;
    this.curLinear = 0;
    this.setStartTime(startTime);
  }
}

MyGraphNode.prototype.nextCombo = function(startTime) {
  this.curCombo++;
  this.curLinear = 0;
  this.setStartTime(startTime);
}

MyGraphNode.prototype.nextLinear = function(startTime) {
  this.curLinear++;
  this.setStartTime(startTime);
}
