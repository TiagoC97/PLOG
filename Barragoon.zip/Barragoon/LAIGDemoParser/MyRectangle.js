/**
* MyRectangle
* @constructor
*/
function MyRectangle(scene, args) {
  CGFobject.call(this,scene);

  this.args = args;

  this.initBuffers();
};

MyRectangle.prototype = Object.create(CGFobject.prototype);
MyRectangle.prototype.constructor = MyRectangle;

MyRectangle.prototype.initBuffers = function() {
  this.vertices = [
    this.args[2], this.args[1], 0, //(1,1)  Top-right
    this.args[0], this.args[1], 0, //(0,1)  Top-left
    this.args[2], this.args[3], 0, //(1,0)  Bottom-right
    this.args[0], this.args[3], 0  //(0,0)  Bottom-left
  ];

  console.log(this.vertices);

  this.indices = [
    0, 1, 2,
    2, 1, 3
  ];

  this.normals = [
    0, 0, 1,
    0, 0, 1,
    0, 0, 1,
    0, 0, 1
  ];


  this.texCoords = [];

  this.dist_s = Math.abs(this.args[0] - this.args[2]);
  this.dist_t = Math.abs(this.args[1] - this.args[3]);

  this.primitiveType = this.scene.gl.TRIANGLES;
  this.initGLBuffers();
};


MyRectangle.prototype.setAmplifFactor = function(amplif_s, amplif_t) {
  if (this.dist_s/amplif_s != this.texCoords[0] || 1 - this.dist_t/amplif_t != this.texCoords[1]) {

  this.texCoords = [
  this.dist_s/amplif_s, 1 - this.dist_t/amplif_t,
  0, 1 - this.dist_t/amplif_t,
  this.dist_s/amplif_s, 1,
  0, 1
];

this.updateTexCoordsGLBuffers();
  }
}
