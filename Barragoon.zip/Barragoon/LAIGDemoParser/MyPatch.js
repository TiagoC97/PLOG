/**
* MyPatch
* @constructor
*/
function MyPatch(scene, args, ctrlvertexes) {
  CGFobject.call(this,scene);

  //Valores recebidos
  this.scene = scene;
  this.partsU = args[0];
  this.partsV = args[1];
  this.ctrlvertexes = ctrlvertexes;

  //Calculo dos graus U e V e respetivos vetores de 0s e 1s
  this.degreeU = this.ctrlvertexes.length - 1;
  this.degreeV = this.ctrlvertexes[0].length - 1;
  this.knotsU = this.getKnotsVector(this.degreeU);
  this.knotsV = this.getKnotsVector(this.degreeV);

  this.initBuffers();
};

MyPatch.prototype = Object.create(CGFnurbsObject.prototype);
MyPatch.prototype.constructor = MyPatch;

MyPatch.prototype.initBuffers = function() {

  var nurbsSurface = new CGFnurbsSurface(this.degreeU, this.degreeV, this.knotsU, this.knotsV, this.ctrlvertexes);
  getSurfacePoint = function(u, v) {
    return nurbsSurface.getPoint(u, v);
  };
  this.obj = new CGFnurbsObject(this.scene, getSurfacePoint, this.partsU, this.partsV);

  this.primitiveType = this.scene.gl.TRIANGLES;
};

MyPatch.prototype.getKnotsVector = function(degree) {
  //Cria vetor de 0s e 1s dependendo do grau
  var v = new Array();
  for (let i = 0; i <= degree; i++) {
    v.push(0);
  }
  for (let i = 0; i <= degree; i++) {
    v.push(1);
  }
  return v;
}

MyPatch.prototype.setAmplifFactor = function(amplif_s, amplif_t) {}

MyPatch.prototype.display = function() {
  this.obj.display();
}
