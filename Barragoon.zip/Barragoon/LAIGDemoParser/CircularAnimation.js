/**
* CircularAnimation
* @constructor
*/
function CircularAnimation(scene, speed, center, radius, startAng, rotAng) {
  Animation.call(this, scene);

  this.centerX = center[0];
  this.centerY = center[1];
  this.centerZ = center[2];

  this.radius = radius;
  this.startAng = startAng * DEGREE_TO_RAD;

  this.speedAng = speed / radius;

  this.ang = startAng * DEGREE_TO_RAD;
  this.angMax = (startAng + rotAng) * DEGREE_TO_RAD;
  this.dir = Math.sign(rotAng);

  if (this.dir > 0)
  this.flip = true;
  else this.flip = false;
};


CircularAnimation.prototype.update = function(curTime, curNode) {

  let startTime = curNode.startTime;

  let deltaT = (curTime - startTime) / 1000;

  this.ang = this.startAng + this.speedAng * deltaT * this.dir;

  if (this.ang * this.dir >= this.angMax * this.dir) {
    this.ang = this.angMax;
    return DONE;
  }
  return CONTINUE;
}


CircularAnimation.prototype.applyMatrix = function() {
  this.scene.translate(this.centerX, this.centerY, this.centerZ);
  this.scene.rotate(this.ang, 0, 1, 0);
  this.scene.translate(this.radius, 0, 0);
  if (this.flip) this.scene.rotate(Math.PI, 0, 1, 0);
}
